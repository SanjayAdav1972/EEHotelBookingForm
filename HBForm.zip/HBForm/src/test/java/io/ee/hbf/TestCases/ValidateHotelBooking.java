package io.ee.hbf.TestCases;

import org.testng.annotations.Test;

import io.ee.hbf.PageObjects.HotelBookingHomePage;
import io.ee.hbf.PageObjects.HotelBookingLandingPage;
import io.ee.hbf.Setup.TestSetup;

public class ValidateHotelBooking extends TestSetup {
	
	
	@Test(priority=1)
	public void hotelBookingE2ESaveAndDelete() {
		// webdriver
		// natigate to url
		// enter booking details and save
		HotelBookingLandingPage landingPage = new HotelBookingLandingPage().open();
		
		// Save Booking and then delete the same saved booking
		HotelBookingHomePage homePage = landingPage.doSaveAndDeleteHotelBooking("Sanjay54321", "lstname", "500", "2018-08-08", "2018-08-15");
	}
	
	/*
	@Test(priority=2)
	public void doHotelBookingwithValidData() {
		// webdriver
		// natigate to url
		// enter booking details and save
		HotelBookingLandingPage landingPage = new HotelBookingLandingPage().open();
		HotelBookingHomePage homePage = landingPage.doHotelBooking("Sanjay54321", "lstname", "500", "2018-08-08", "2018-08-15");
	}
	
	@Test(priority=3)
	public void deleteHotelBooking() {
		HotelBookingLandingPage landingPage = new HotelBookingLandingPage().open();
		HotelBookingHomePage homePage = landingPage.deleteHotelBooking("Sanjay54321", "lstname", "500", "2018-08-08", "2018-08-15");
		
	}
	 */
}

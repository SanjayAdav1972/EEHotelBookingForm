
package io.ee.hbf.Rough;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.ee.hbf.PageObjects.HotelBookingLandingPage;


// Kindly nore this code is written to place the code in POM design parts.
// Verify the functionality is working in linear function
public class SampleTestCase {

	@Test(dataProvider="getData")
	public void tc_01(String firstName, String lastName, String price, String checkIn, String checkOut) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "D:\\Projects\\HBForm\\src\\test\\resources\\executables\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://hotel-test.equalexperts.io/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20,  TimeUnit.SECONDS);

		List<WebElement> beforeAddition = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntBefore = beforeAddition.size();
		System.out.println(cntBefore);
		
		
		driver.findElement(By.id("firstname")).sendKeys(firstName);
		driver.findElement(By.id("lastname")).sendKeys(lastName);
		driver.findElement(By.id("totalprice")).sendKeys(price);
		driver.findElement(By.id("checkin")).sendKeys(checkIn);
		driver.findElement(By.id("checkout")).sendKeys(checkOut);
		driver.findElement(By.xpath("//input[@type='button' and @value=' Save ']")).click();
		
		
		/*Thread.sleep(5000);
		HotelBookingLandingPage hotelBooking = new HotelBookingLandingPage(driver);
		hotelBooking.firstName.sendKeys(firstName);
		hotelBooking.lastName.sendKeys(lastName);
		hotelBooking.totalPrice.sendKeys(price);
		hotelBooking.checkIn.sendKeys(checkIn);
		hotelBooking.checkOut.sendKeys(checkOut);
		hotelBooking.saveButton.click();
		Thread.sleep(5000);*/
		
		// verify the added element exists for deletion
		List<WebElement> newElement = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntAfter = newElement.size();
		System.out.println(cntAfter);
		Assert.assertEquals(cntBefore+1, cntAfter);
		
		driver.quit();
		
	}
	
	@Test(dataProvider="getData")
	public void tc_02(String firstName, String lastName, String price, String checkIn, String checkOut) throws InterruptedException {
		System.setProperty("webdriver.gecko.driver", "D:\\Projects\\HBForm\\src\\test\\resources\\executables\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://hotel-test.equalexperts.io/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20,  TimeUnit.SECONDS);
	
		Thread.sleep(5000);
		
		// Delete the just entered data
		// //p[contains(text(),'Sanjay')]//..//..//input[@type='button' and @value='Delete']
		String delelement = ".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']";
		System.out.println(delelement);
		
		driver.findElement(By.xpath(delelement)).click();
		Thread.sleep(5000);
		driver.quit();
	}
	
	@DataProvider
	public Object[][] getData(){
		Object[][] data = new Object[1][5];
		data[0][0] = "Sanjay12345";
		data[0][1] = "adav";
		data[0][2] = "500";
		data[0][3] = "2018-08-08";
		data[0][4] = "2018-08-15";
		return data;
	}

}

package io.ee.hbf.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

//All web elements of Hotel booking are stored here with their unique attributes like id, xpath, css, etc
//Over getPageLoadCondition method with control need to be loaded before performing any action on the page
public class HotelBookingLandingPage extends BasePage {

	/*public HotelBookingLandingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}*/
	
	public HotelBookingLandingPage open() {
		return (HotelBookingLandingPage) openPage(HotelBookingLandingPage.class);
	}

	@Override
	public ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(saveButton);
	}
	
	public void waitTillPageRgreshwillNewData() throws InterruptedException {
		Thread.sleep(10000);
	}
	
	public void waitTillElementReady(String xpath) {
		WebElement element = null;
 
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		 
		element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath)));
		System.out.println("2");
	}
	
	@FindBy(id = "firstname")
	public WebElement firstName;

	@FindBy(id = "lastname")
	public WebElement lastName;

	@FindBy(id = "totalprice")
	public WebElement totalPrice;

	@FindBy(id = "checkin")
	public WebElement checkIn;

	@FindBy(id = "checkout")
	public WebElement checkOut;

	@FindBy(xpath = "//input[@type='button' and @value=' Save ']")
	public WebElement saveButton;

	@FindBy(xpath = "//input[@type='button' and @value='Delete']")
	public WebElement deleteButton;
		
	// The action to do booking with the provided data and then perform saving for the saved booking.
	public HotelBookingHomePage doSaveAndDeleteHotelBooking(String firstName, String lastName, String price, String checkIn, String checkOut) {
		// Before booking verify if the recird with save firstname exist. If exists then record=0 else some count
		List<WebElement> beforeAddition = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntBefore = beforeAddition.size();
		System.out.println("Records before save:" + cntBefore);
		
		this.firstName.sendKeys(firstName);
		this.lastName.sendKeys(lastName);
		this.totalPrice.sendKeys(price);
		this.checkIn.sendKeys(checkIn);
		this.checkOut.sendKeys(checkOut);
		this.saveButton.click();
		
		// Wait till page refresh with saved data. 
		// Can be used WebDriver Wait till condition satisfies
		try {
			this.waitTillPageRgreshwillNewData();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		// verify the added element exists for deletion, count should be geater than the previous count
		// I have used this logic because currently no confirmation message displayed and also no count on table/grid
		List<WebElement> newElement = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntAfter = newElement.size();
		System.out.println("Records after save:" + cntAfter);
		
		// Before booking saved successfully
		// I have used hard testng assert here. If no record saved no point it going to next step of deletion the record.
		Assert.assertEquals(cntBefore+1, cntAfter);		
	
		System.out.println("reached here. ready for deletion");
			
		String delelement = ".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']";
		//System.out.println(delelement);
		waitTillElementReady(delelement);
		
		// I have used findElements instead of fineElement because findElements return list of records as the system allow duplicate records
		List<WebElement> lst = driver.findElements(By.xpath(delelement));
		if (lst.size()>0) {
			System.out.println("Record exists for deletion");
			driver.findElement(By.xpath(delelement)).click();
		}
		else {
			System.out.println("No Record exists for deletion");
		}
		
		// return to HotelBookingHomePage after booking saved and deleted successfully
		return (HotelBookingHomePage) openPage(HotelBookingHomePage.class);
	}
	
	// Do booking
	public HotelBookingHomePage doHotelBooking(String firstName, String lastName, String price, String checkIn, String checkOut) {
		// note record count with with passed firstname
		List<WebElement> beforeAddition = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntBefore = beforeAddition.size();
		System.out.println(cntBefore);
		
		this.firstName.sendKeys(firstName);
		this.lastName.sendKeys(lastName);
		this.totalPrice.sendKeys(price);
		this.checkIn.sendKeys(checkIn);
		this.checkOut.sendKeys(checkOut);
		this.saveButton.click();
		
		try {
			this.waitTillPageRgreshwillNewData();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// verify the added element exists for deletion
		List<WebElement> newElement = driver.findElements(By.xpath(".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']"));
		int cntAfter = newElement.size();
		System.out.println(cntAfter);
		Assert.assertEquals(cntBefore+1, cntAfter);
				
		// return to HotelBookingHomePage after booking saved successfully
		return (HotelBookingHomePage) openPage(HotelBookingHomePage.class);
	}
	
	// delete booking
	public HotelBookingHomePage deleteHotelBooking(String firstName, String lastName, String price, String checkIn, String checkOut) {
		String delelement = ".//p[contains(text(),'" + firstName + "')]//..//..//input[@type='button' and @value='Delete']";
		//System.out.println(delelement);
		waitTillElementReady(delelement);
		
		// I have used findElements instead of fineElement because findElements return list of records as the system allow duplicate records
		List<WebElement> lst = driver.findElements(By.xpath(delelement));
		if (lst.size()>0) {
			System.out.println("Record exists for deletion");
			driver.findElement(By.xpath(delelement)).click();
		}
		else {
			System.out.println("No Record exists for deletion");
		}
				
		// return to HotelBookingHomePage after booking deleted successfully
		return (HotelBookingHomePage) openPage(HotelBookingHomePage.class);
	}
	
	
	// Negative test cases. Partially implementation done as the system allowed duplicate record save,
	public HotelBookingLandingPage doHotelBookingWithInvalidData(String firstName, String lastName, String price, String checkIn, String checkOut) {
		this.firstName.sendKeys(firstName);
		this.lastName.sendKeys(lastName);
		this.totalPrice.sendKeys(price);
		this.checkIn.sendKeys(checkIn);
		this.checkOut.sendKeys(checkOut);
		this.saveButton.click();
		
		return this;		// return to the same page as booking will not be saved
	}
	
}

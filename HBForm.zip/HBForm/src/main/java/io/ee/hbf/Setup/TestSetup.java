package io.ee.hbf.Setup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import io.ee.hbf.TestUtils.ExcelReader;

// All test setup activities like WebDriver, excel reader, property intialisation and read
// Separate WebDriver manager impleemntation is pending
public class TestSetup {
	public static WebDriver driver;
	public static Properties configProperty;
	
	public ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\testData\\simple.xlsx");
	
	@BeforeSuite	
	public void beforeSuit() {
		// excel reader class instantiation
		// property file instantiation
		// extent report instantiation
		
		try {
			FileInputStream fi = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\propertyFIles\\config.properties"));
			configProperty = new Properties();
			try {
				configProperty.load(fi);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//extent = ExtentManager.GetExtent();
	}
	
	@AfterSuite	
	public void afterSuit() {
		
	}
	
	@BeforeTest	
	public void beforeTest() {
		
	}
	
	@AfterTest	
	public void afterTest() {
		
	}
	
	@BeforeClass	
	public void beforeClass() {
		
	}
	
	@AfterClass
	public void afterClass() {
		
	}
	
	@BeforeMethod	
	public void beforeMethod() {
		// logging 	
		// web driver
		// extent report
		//driver = null;
		
		// Initialise based on the provide config and open the url
		System.out.println("Driver Status:" + driver);
		if (driver == null) {
			if (configProperty.getProperty("browser").equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\geckodriver.exe");
				driver = new FirefoxDriver();
			}
			else if (configProperty.getProperty("browser").equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
				driver = new ChromeDriver();
			}
			else if (configProperty.getProperty("browser").equalsIgnoreCase("ie")) {
				// todo for ie browser
			}
		}
		
		driver.navigate().to(configProperty.getProperty("url"));
	}
	
	@AfterMethod
	public void afterMethod() {
		// browser close/quit
		// test link updates
		// extent report flush
		driver.quit();		// Close all open instances of webdrivers
	}
}

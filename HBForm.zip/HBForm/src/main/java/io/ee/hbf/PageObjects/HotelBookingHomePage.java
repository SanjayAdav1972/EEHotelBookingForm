package io.ee.hbf.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

// All web elements of Hotel booking are stored here with their unique attributes like id, xpath, css, etc
// Over getPageLoadCondition method with control need to be loaded before performing any action on the page
public class HotelBookingHomePage extends BasePage {

	@FindBy(xpath = "//input[@type='button' and @value=' Save ']")
	public WebElement saveButton;

	@Override
	public ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(saveButton);
	}
	
}
